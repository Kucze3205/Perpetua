cd "$(dirname "$0")" && python3 script facts.json
